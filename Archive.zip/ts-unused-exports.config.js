module.exports = {
  entryPoints: ['src/app/layout.tsx', 'src/app/page.tsx'],
  project: 'tsconfig.json',
  ignoreFiles: ['**/*.test.ts', '**/*.test.tsx', '**/*.stories.tsx'],
};
