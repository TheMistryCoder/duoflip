export const duoFlipVideoUrl = "https://innov8graphics.com/img/duo-flip-video.mp4";
